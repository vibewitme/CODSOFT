let output = "0";

function appendToOutput(value) {
    if (output === "0" || output === "Error") {
        output = value;
    } else {
        output += value;
    }
    updateDisplay();
}

function calculate() {
    try {
        output = eval(output).toString();
        if (output === "Infinity" || output === "-Infinity" || output === "NaN") {
            output = "Error";
        }
        updateDisplay();
    } catch (error) {
        output = "Error";
        updateDisplay();
    }
}

function clearOutput() {
    output = "0";
    updateDisplay();
}

function updateDisplay() {
    document.getElementById("output").textContent = output;
}
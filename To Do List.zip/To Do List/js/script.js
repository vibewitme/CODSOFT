AOS.init();

const reviewContainer = document.querySelector('.review-container');
const prevSlideArrow = document.querySelector('.prev-slide');
const nextSlideArrow = document.querySelector('.next-slide');
const cardWidth = 33; // Adjust the card width as needed
const visibleCards = 3; // Number of cards to display at a time
let currentIndex = 0;
const totalCards = reviewContainer.children.length;
const maxIndex = Math.ceil(totalCards / visibleCards) - 1;
currentIndex = Math.min(maxIndex, currentIndex);



function updateReviewSlider() {
    const totalCards = reviewContainer.children.length;
    currentIndex = Math.min(totalCards - visibleCards, currentIndex);

    const translateX = `translateX(-${currentIndex * cardWidth}%)`;
    reviewContainer.style.transform = translateX;

    prevSlideArrow.style.display = currentIndex === 0 ? 'none' : 'block';
    nextSlideArrow.style.display = currentIndex === maxIndex ? 'none' : 'block'; // Updated this line
}


// Event listener for the "Next" button
nextSlideArrow.addEventListener('click', function () {
    currentIndex += 1;
    updateReviewSlider();
});

// Event listener for the "Previous" button
prevSlideArrow.addEventListener('click', function () {
    currentIndex -= 1;
    updateReviewSlider();
});

// Initially, update the slider to show the first set of cards
updateReviewSlider();

const toggleButton = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');

toggleButton.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

// Get all the nav-links within the navbar
const navLinksList = navLinks.querySelectorAll('a');

// Add a click event listener to each nav-link
navLinksList.forEach((link) => {
    link.addEventListener('click', () => {
        // Remove the 'active' class from the navbar
        navLinks.classList.remove('active');
    });
});

document.querySelectorAll('nav a').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        const targetId = this.getAttribute('href').substring(1); // Get the target section id
        const targetSection = document.getElementById(targetId);

        if (targetSection) {
            targetSection.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});



